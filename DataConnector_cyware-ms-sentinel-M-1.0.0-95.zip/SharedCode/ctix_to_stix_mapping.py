"""This module maps Cyware CTIX Saved Result Set (v3) objects to STIX 2.1 indicators."""

import json
import uuid
from datetime import datetime, timezone
from SharedCode import consts


class UnsupportedIndicatorException(Exception):
    """Raised when a CTIX object cannot be converted into a STIX indicator."""


def _to_stix_timestamp(epoch_value):
    """Convert an epoch timestamp (seconds, may contain fractions) to a STIX timestamp.

    Args:
        epoch_value (int|float|None): Epoch seconds.

    Returns:
        str: ISO 8601 UTC timestamp with millisecond precision and 'Z' suffix, or None.
    """
    if epoch_value in (None, ""):
        return None
    try:
        timestamp = datetime.fromtimestamp(float(epoch_value), tz=timezone.utc)
    except (TypeError, ValueError, OverflowError, OSError):
        return None
    return timestamp.strftime("%Y-%m-%dT%H:%M:%S.") + "{:03d}Z".format(timestamp.microsecond // 1000)


def _escape_pattern_value(value):
    """Escape a value for use inside a single-quoted STIX pattern string.

    Args:
        value (str): Raw observable value.

    Returns:
        str: Value with backslashes and single quotes escaped.
    """
    return value.replace("\\", "\\\\").replace("'", "\\'")


def get_ioc_type(ctix_object):
    """Get the IOC type of a CTIX indicator; for files the hash algorithm (e.g. SHA-256) or 'file-name'.

    CTIX sends file indicators as indicator_type {"type": "file", "attribute_field": "SHA-256"}, with the bare
    hash algorithm (or "name" for a file name) in attribute_field.

    Args:
        ctix_object (dict): CTIX Saved Result Set v3 object.

    Returns:
        str: IOC type.
    """
    indicator_type = ctix_object.get("indicator_type") or {}
    observable_type = str(indicator_type.get("type") or ctix_object.get("ioc_type") or "").strip()
    if observable_type == "file":
        attribute_field = str(indicator_type.get("attribute_field") or "")
        if attribute_field == "name":
            return consts.FILE_NAME_IOC_TYPE
        algorithm = attribute_field.replace(consts.HASHES_PREFIX, "").strip("'\" ")
        if not algorithm:
            return str(ctix_object.get("ioc_type") or observable_type)
        return consts.HASH_ALGORITHMS.get(algorithm.upper(), algorithm)
    return observable_type


def _build_artifact_pattern(value, attribute_field):
    """Build the STIX pattern of a CTIX artifact indicator.

    The property comes from the CTIX attribute_field (a hash algorithm such as "SHA-256", "hashes.'SHA-256'", "url" or
    "payload_bin"). When CTIX sends the generic "value", a hash is recognised by its length and a URL by its scheme.

    Args:
        value (str): Value of the artifact indicator.
        attribute_field (str): CTIX attribute_field of the indicator.

    Returns:
        str: STIX pattern, e.g. "[artifact:hashes.'SHA-256' = '...']".

    Raises:
        UnsupportedIndicatorException: If the property of the artifact cannot be determined.
    """
    if attribute_field.startswith(consts.HASHES_PREFIX):
        path = attribute_field
    elif attribute_field.upper() in consts.HASH_ALGORITHMS:
        path = consts.HASH_PATH_FORMAT.format(consts.HASH_ALGORITHMS[attribute_field.upper()])
    elif attribute_field in consts.ARTIFACT_PATTERN_PROPERTIES:
        path = attribute_field
    elif all(char in "0123456789abcdefABCDEF" for char in value) and len(value) in consts.HASH_LENGTH_ALGORITHMS:
        path = consts.HASH_PATH_FORMAT.format(consts.HASH_LENGTH_ALGORITHMS[len(value)])
    elif value.lower().startswith(("http://", "https://")):
        path = "url"
    else:
        raise UnsupportedIndicatorException("unsupported artifact indicator '{}'".format(attribute_field))
    return "[artifact:{} = '{}']".format(path, _escape_pattern_value(value))


def _build_pattern(ctix_object):
    """Build the STIX pattern of a CTIX indicator.

    Args:
        ctix_object (dict): CTIX Saved Result Set v3 object.

    Returns:
        str: STIX pattern, e.g. "[ipv4-addr:value = '1.2.3.4']".

    Raises:
        UnsupportedIndicatorException: If the indicator type cannot be mapped to a STIX pattern.
    """
    value = str(ctix_object.get("name") or ctix_object.get("sdo_name") or "").strip()
    if not value:
        raise UnsupportedIndicatorException("indicator has no value")
    indicator_type = ctix_object.get("indicator_type") or {}
    observable_type = (indicator_type.get("type") or ctix_object.get("ioc_type") or "").strip()
    attribute_field = (indicator_type.get("attribute_field") or "value").strip()
    ioc_type = str(ctix_object.get("ioc_type") or "").strip()

    if observable_type == "file" or ioc_type.upper() in consts.HASH_ALGORITHMS:
        if attribute_field.startswith(consts.HASHES_PREFIX):
            path = attribute_field
        elif attribute_field.upper() in consts.HASH_ALGORITHMS:
            # CTIX sends the bare hash algorithm, e.g. "SHA-256".
            path = consts.HASH_PATH_FORMAT.format(consts.HASH_ALGORITHMS[attribute_field.upper()])
        elif attribute_field == "name":
            path = "name"
        elif ioc_type.upper() in consts.HASH_ALGORITHMS:
            path = consts.HASH_PATH_FORMAT.format(consts.HASH_ALGORITHMS[ioc_type.upper()])
        else:
            raise UnsupportedIndicatorException(
                "unsupported file indicator '{}' ({})".format(attribute_field, ioc_type)
            )
        return "[file:{} = '{}']".format(path, _escape_pattern_value(value))

    if observable_type == consts.YARA_IOC_TYPE:
        # CTIX sends only the rule name for a YARA indicator; it is stored as the YARA pattern.
        return value
    if observable_type == "software":
        # CTIX attribute_field is "value" by default; a STIX software object keeps its value in "name".
        return "[software:{} = '{}']".format(
            attribute_field if attribute_field != "value" else "name", _escape_pattern_value(value)
        )
    if observable_type == "artifact":
        return _build_artifact_pattern(value, attribute_field)
    if observable_type not in consts.SUPPORTED_OBSERVABLE_TYPES:
        raise UnsupportedIndicatorException(
            "indicator type '{}' is not mapped to a STIX pattern".format(observable_type)
        )
    if (observable_type, attribute_field) in consts.INTEGER_PATTERN_PROPERTIES:
        # Integer STIX properties (AS number, ports); CTIX sends AS numbers with an "AS" prefix, e.g. "AS64512".
        number = value[2:] if observable_type == "autonomous-system" and value[:2].upper() == "AS" else value
        if not number.isdigit():
            raise UnsupportedIndicatorException(
                "indicator value '{}' is not a valid {} {}".format(value, observable_type, attribute_field)
            )
        return "[{}:{} = {}]".format(observable_type, attribute_field, int(number))
    return "[{}:{} = '{}']".format(observable_type, attribute_field, _escape_pattern_value(value))


def _get_names(values):
    """Get the names from a CTIX tag value (a list of strings or objects, null, or {"name": [...]}).

    Args:
        values (list|dict|None): CTIX tags.

    Returns:
        list: Unique, non-empty names in original order.
    """
    if isinstance(values, dict):
        values = values.get("name") or []
    if not isinstance(values, list):
        return []
    names = []
    for value in values:
        name = value.get("name") if isinstance(value, dict) else value
        if name and str(name).strip():
            names.append(str(name).strip())
    return list(dict.fromkeys(names))


def _get_tags(ctix_object, record_tags, enrichment):
    """Get the tag names of an indicator from all three CTIX sources.

    Combines the tags of the Saved Result Set object, the 'ctix_tags' of the Saved Result Set record and the tags
    returned by the Bulk IOC Lookup API.

    Args:
        ctix_object (dict): CTIX Saved Result Set v3 object.
        record_tags (list): Tag names ('ctix_tags') of the Saved Result Set record.
        enrichment (dict): Bulk IOC Lookup result of the indicator, or None.

    Returns:
        list: Unique tag names in original order.
    """
    return list(dict.fromkeys(
        _get_names(ctix_object.get("tags")) + list(record_tags or []) + _get_names((enrichment or {}).get("tags"))
    ))


def _get_relations(ctix_object, enrichment):
    """Get the related object names per relation type used by the workbook.

    The Bulk IOC Lookup API returns relations as {"<type>": ["<name>", ...]}; Saved Result Set objects can
    carry relationship objects with source/target types and names. Both are merged.

    Args:
        ctix_object (dict): CTIX Saved Result Set v3 object.
        enrichment (dict): Bulk IOC Lookup result of the indicator, or None.

    Returns:
        dict: Relation type -> list of related object names, for the types in CTIX_RELATION_TYPES.
    """
    relations = {relation_type: [] for relation_type in consts.CTIX_RELATION_TYPES}
    lookup_relations = (enrichment or {}).get("relations")
    if isinstance(lookup_relations, dict):
        for relation_type, names in lookup_relations.items():
            if relation_type in relations:
                relations[relation_type].extend(_get_names(names))
    for relation in ctix_object.get("relations") or []:
        if not isinstance(relation, dict):
            continue
        for side in ("target", "source"):
            relation_type = relation.get("{}_type".format(side))
            name = relation.get("{}_name".format(side))
            if relation_type in relations and name and name != ctix_object.get("name"):
                relations[relation_type].append(str(name))
    return {relation_type: list(dict.fromkeys(names)) for relation_type, names in relations.items()}


def _parse_json_value(value):
    """Parse a JSON-encoded string value, returning the original value if it is not JSON.

    Args:
        value: Value that may be a JSON object or array encoded as a string.

    Returns:
        The decoded value, or the original value.
    """
    if isinstance(value, str) and value.strip()[:1] in ("{", "["):
        try:
            return json.loads(value)
        except ValueError:
            return value
    return value


def _iter_custom_attributes(ctix_object, enrichment):
    """Yield the (name, value) pairs of the custom attributes of the lookup result and the saved result.

    Args:
        ctix_object (dict): CTIX Saved Result Set v3 object.
        enrichment (dict): Bulk IOC Lookup result of the indicator, or None.

    Yields:
        tuple: (attribute name as text, decoded attribute value), lookup attributes first.
    """
    for attributes in ((enrichment or {}).get("custom_attributes"), ctix_object.get("custom_attributes")):
        for attribute in attributes if isinstance(attributes, list) else []:
            if not isinstance(attribute, dict):
                continue
            name = attribute.get("custom_attribute_name", attribute.get("name"))
            if name:
                value = attribute.get("custom_attribute_value", attribute.get("value"))
                yield str(name), _parse_json_value(value)


def _get_custom_attributes(ctix_object, enrichment):
    """Get the custom attributes of an indicator as a list of {name: value} objects.

    The Bulk IOC Lookup API returns 'custom_attribute_name'/'custom_attribute_value' (values can be
    JSON-encoded strings); Saved Result Set objects use 'name'/'value'. The attributes of both are combined
    (lookup first) and an attribute with the same name and value is kept once.

    Args:
        ctix_object (dict): CTIX Saved Result Set v3 object.
        enrichment (dict): Bulk IOC Lookup result of the indicator, or None.

    Returns:
        list: [{<attribute name>: <value>}], e.g. [{"risk": 66}, {"criticality": 3}].
    """
    result = []
    seen = set()
    for name, value in _iter_custom_attributes(ctix_object, enrichment):
        # The two APIs can return the same value as text and as a number, e.g. "66" and 66.
        key = (name, value if isinstance(value, str) else json.dumps(value, sort_keys=True))
        if key not in seen:
            seen.add(key)
            result.append({name: value})
    return result


def _get_enrichment(enrichment):
    """Get the enrichment results of an indicator exactly as the Bulk IOC Lookup API returns them.

    Every key of each result is kept ('tool' and 'tool_response'), and 'tool_response' stays the raw string CTIX
    sends. A Log Analytics string value is limited to 256 KB, so the tail of a
    longer 'tool_response' is cut by Microsoft Sentinel.

    Args:
        enrichment (dict): Bulk IOC Lookup result of the indicator, or None.

    Returns:
        list: One object per enrichment tool.
    """
    results = []
    for item in (enrichment or {}).get("enrichment_data") or []:
        if not isinstance(item, dict):
            continue
        entry = {key: value for key, value in item.items() if value not in (None, "")}
        if entry:
            results.append(entry)
    return results


def _get_confidence(ctix_object):
    """Get the STIX confidence of a CTIX object (analyst score overrides the CTIX score).

    Args:
        ctix_object (dict): CTIX Saved Result Set v3 object.

    Returns:
        int: Confidence between 0 and 100, or None when CTIX has no score.
    """
    for key in ("analyst_score", "ctix_score"):
        score = _get_score(ctix_object.get(key))
        if score is not None:
            return score
    return None


def _get_score(value):
    """Convert a CTIX score to an integer between 0 and 100.

    Args:
        value: CTIX score (number, numeric string, "NA" or None).

    Returns:
        int: Score, or None when the value is empty or not a number.
    """
    if value in (None, ""):
        return None
    try:
        return max(0, min(100, int(round(float(value)))))
    except (TypeError, ValueError):
        return None


def _get_tlp(ctix_object):
    """Get the current TLP of a CTIX object (analyst TLP, else CTIX TLP, else source TLP).

    Args:
        ctix_object (dict): CTIX Saved Result Set v3 object.

    Returns:
        str: TLP in upper case, or None when CTIX has no TLP.
    """
    for key in ("analyst_tlp", "ctix_tlp", "source_tlp"):
        tlp = str(ctix_object.get(key) or "").strip().upper()
        if tlp and tlp != "NONE":
            return tlp
    return None


def _get_stix_id(ctix_object):
    """Get the STIX id of an indicator, reusing the CTIX object id when it is a UUID.

    Args:
        ctix_object (dict): CTIX Saved Result Set v3 object.

    Returns:
        str: STIX indicator id.
    """
    ctix_id = str(ctix_object.get("id") or "")
    try:
        return "indicator--{}".format(uuid.UUID(ctix_id))
    except ValueError:
        value = "{}|{}".format(ctix_object.get("ioc_type"), ctix_object.get("name"))
        return "indicator--{}".format(uuid.uuid5(uuid.NAMESPACE_URL, value))


def _build_extension(ctix_object, record_tags, enrichment, relations):
    """Build the CTIX property extension with the fields used by the Cyware CTIX workbook.

    The fields are stored directly under the STIX 'extensions' property (read in KQL as
    Data.extensions.<field>), the same layout as other Microsoft Sentinel threat intelligence connectors.

    Args:
        ctix_object (dict): CTIX Saved Result Set v3 object.
        record_tags (list): Tag names of the Saved Result Set record.
        enrichment (dict): Bulk IOC Lookup result of the indicator, or None (its tags and custom attributes are merged).
        relations (dict): Relation type -> related object names.

    Returns:
        dict: STIX 'extensions' property.
    """
    lookup = enrichment or {}
    extension = {
        "extension_type": "property-extension",
        "ctix_id": str(ctix_object.get("id")),
        "ioc_type": get_ioc_type(ctix_object),
        "ctix_score": _get_score(ctix_object.get("ctix_score")),
        "tlp": _get_tlp(ctix_object),
        "ctix_created": _to_stix_timestamp(ctix_object.get("ctix_created")),
        "ctix_modified": _to_stix_timestamp(ctix_object.get("ctix_modified")),
        "is_whitelist": bool(ctix_object.get("is_whitelist")),
        "is_deprecated": bool(ctix_object.get("is_deprecated")),
        "is_false_positive": bool(ctix_object.get("is_false_positive")),
        "is_revoked": bool(ctix_object.get("is_revoked")),
        "is_actioned": bool(ctix_object.get("is_actioned")),
        "is_reviewed": bool(ctix_object.get("is_reviewed")),
        "custom_scores": ctix_object.get("custom_scores"),
        "country": ctix_object.get("country"),
        "severity": ctix_object.get("severity"),
        "sources": sorted({str(src.get("name")) for src in ctix_object.get("sources") or [] if src.get("name")}),
        "tags": _get_tags(ctix_object, record_tags, enrichment),
        "manual_review": bool(lookup["manual_review"]) if lookup.get("manual_review") is not None else None,
        "relations": relations,
        "custom_attributes": _get_custom_attributes(ctix_object, enrichment),
        "enrichment": _get_enrichment(enrichment),
        "first_seen": lookup.get("first_seen"),
        "last_seen": lookup.get("last_seen"),
        "sub_type": lookup.get("sub_type"),
        "published_collections": lookup.get("published_collections"),
        "indicator_url": "{}/ctix/threatdata/indicator/{}/overview".format(
            consts.CTIX_BASE_URL[: -len("/ctixapi")] if consts.CTIX_BASE_URL.endswith("/ctixapi")
            else consts.CTIX_BASE_URL,
            ctix_object.get("id"),
        ),
    }
    # Sentinel drops keys without data; remove them here so stored objects match what is sent.
    extension = {key: value for key, value in extension.items() if value not in (None, "", [], {})}
    extension["relations"] = {key: names for key, names in relations.items() if names}
    if not extension["relations"]:
        del extension["relations"]
    return extension


def map_ctix_object_to_stix(ctix_object, record_tags=None, enrichment=None, record_timestamp=None):
    """Convert a CTIX Saved Result Set (v3) indicator object into a STIX 2.1 indicator.

    Args:
        ctix_object (dict): CTIX Saved Result Set v3 object.
        record_tags (list): Tag names ('ctix_tags') of the Saved Result Set record the object belongs to.
        enrichment (dict): Bulk IOC Lookup (Advanced) result of the indicator, or None.
        record_timestamp (int): Publish time of the Saved Result Set record. CTIX does not change 'modified' or the
            snapshot's 'ctix_modified' when an indicator is deprecated, so the publish time makes each newer
            snapshot a newer STIX version.

    Returns:
        dict: STIX 2.1 indicator object.

    Raises:
        UnsupportedIndicatorException: If the object is not an indicator or its type is not supported.
    """
    if ctix_object.get("sdo_type") != consts.SUPPORTED_SDO_TYPE:
        raise UnsupportedIndicatorException("object type '{}' is not an indicator".format(ctix_object.get("sdo_type")))

    record_tags = record_tags or []
    pattern = _build_pattern(ctix_object)
    pattern_type = "yara" if get_ioc_type(ctix_object) == consts.YARA_IOC_TYPE else "stix"
    created = _to_stix_timestamp(ctix_object.get("created") or ctix_object.get("ctix_created"))
    if not created:
        raise UnsupportedIndicatorException("indicator has no creation time")
    modified_epoch = max(
        float(value)
        for value in (ctix_object.get("modified"), ctix_object.get("ctix_modified"), ctix_object.get("created"),
                      ctix_object.get("ctix_created"), record_timestamp)
        if value not in (None, "")
    )
    modified = max(created, _to_stix_timestamp(modified_epoch))
    ctix_valid_from = _to_stix_timestamp(ctix_object.get("valid_from"))
    valid_from = ctix_valid_from or created
    # valid_until: the CTIX valid_until when set; otherwise current time + 180 days.
    valid_until = _to_stix_timestamp(ctix_object.get("valid_until"))
    if not valid_until:
        valid_until = _to_stix_timestamp(datetime.now(timezone.utc).timestamp() + consts.VALID_UNTIL_DAYS * 86400)
    relations = _get_relations(ctix_object, enrichment)

    stix_indicator = {
        "type": "indicator",
        "spec_version": consts.STIX_SPEC_VERSION,
        "id": _get_stix_id(ctix_object),
        "created": created,
        "modified": modified,
        "name": consts.STIX_INDICATOR_NAME_FORMAT.format(
            get_ioc_type(ctix_object), str(ctix_object.get("name") or ctix_object.get("sdo_name")).strip()
        ),
        "indicator_types": [
            consts.INDICATOR_TYPE_BENIGN if ctix_object.get("is_whitelist") else consts.INDICATOR_TYPE_MALICIOUS
        ],
        "pattern": pattern,
        "pattern_type": pattern_type,
        "pattern_version": consts.STIX_SPEC_VERSION,
        "valid_from": valid_from,
        "revoked": bool(
            ctix_object.get("is_revoked")
            or ctix_object.get("is_deprecated")
            or ctix_object.get("is_false_positive")
            or ctix_object.get("is_whitelist")
        ),
        "external_references": [
            {
                "source_name": "Cyware CTIX",
                "external_id": str(ctix_object.get("id")),
                "description": "Severity: {}; Sources: {}".format(
                    ctix_object.get("severity") or "UNKNOWN",
                    ", ".join(
                        sorted({str(src.get("name")) for src in ctix_object.get("sources") or [] if src.get("name")})
                    )
                    or "None",
                ),
            }
        ],
        "extensions": _build_extension(ctix_object, record_tags, enrichment, relations),
    }
    if pattern_type == "yara":
        # pattern_version is the version of the STIX pattern language; it does not apply to a YARA pattern.
        del stix_indicator["pattern_version"]
    if valid_until and valid_until > valid_from:
        stix_indicator["valid_until"] = valid_until
    confidence = _get_confidence(ctix_object)
    if confidence is not None:
        stix_indicator["confidence"] = confidence
    labels = list(dict.fromkeys(_get_tags(ctix_object, record_tags, enrichment) + relations["attack-pattern"]))
    if labels:
        stix_indicator["labels"] = labels
    tlp = _get_tlp(ctix_object)
    if tlp in consts.TLP_MARKING_DEFINITIONS:
        stix_indicator["object_marking_refs"] = [consts.TLP_MARKING_DEFINITIONS[tlp]]
    description = ctix_object.get("analyst_description") or (enrichment or {}).get("description")
    if description:
        stix_indicator["description"] = str(description)
    return stix_indicator
