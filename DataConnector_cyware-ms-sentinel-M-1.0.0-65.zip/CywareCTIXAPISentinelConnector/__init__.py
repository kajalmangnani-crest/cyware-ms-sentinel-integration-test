"""This is init file for CywareCTIXAPISentinelConnector Timer Trigger Function."""

import datetime
import time
import azure.functions as func
from SharedCode import consts
from SharedCode.logger import applogger
from SharedCode.cyware_ctix_exceptions import CywareCTIXTimeoutException
from CywareCTIXAPISentinelConnector.ctix_helper import CywareCTIXHelper


def _log_message(message):
    """Format a log message in the connector's standard format.

    Args:
        message (str): Message to log.

    Returns:
        str: "CywareCTIX(method = main) : CywareCTIXAPISentinelConnector : <message>".
    """
    return consts.LOG_FORMAT.format(consts.LOGS_STARTS_WITH, "main", consts.FUNCTION_NAME, message)


def main(mytimer: func.TimerRequest) -> None:
    """Run the Cyware CTIX indicator ingestion triggered by the timer.

    Args:
        mytimer (func.TimerRequest): The timer trigger request object.
    """
    start = time.time()
    applogger.info(_log_message("Function App started at {}".format(datetime.datetime.fromtimestamp(start))))
    if mytimer.past_due:
        applogger.info(_log_message("The timer is past due."))
    try:
        CywareCTIXHelper(int(start)).run()
    except CywareCTIXTimeoutException:
        applogger.info(_log_message("Function App stopped before its execution limit. Progress saved."))
    except Exception as error:
        applogger.error(_log_message("Function App encountered an error: {}".format(error)))
        raise
    applogger.info(_log_message("Function App ended. Total time taken = {:.2f} seconds".format(time.time() - start)))
