"""Shared modules of the Cyware CTIX Microsoft Sentinel data connector."""
