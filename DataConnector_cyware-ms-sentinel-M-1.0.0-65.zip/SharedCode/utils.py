"""Common helper functions for the Cyware CTIX integration."""

import time
from SharedCode.cyware_ctix_exceptions import CywareCTIXTimeoutException


def ensure_time_left(deadline, seconds_needed):
    """Stop before a request or retry wait that would run past the function's execution limit.

    Args:
        deadline (float|None): Unix time by which the function must stop; None disables the check.
        seconds_needed (float): Time the next request or wait can take.

    Raises:
        CywareCTIXTimeoutException: If the next step could end after the deadline.
    """
    if deadline and time.time() + seconds_needed > deadline:
        raise CywareCTIXTimeoutException(
            "Not enough time left for the next step ({} seconds) before the execution limit".format(
                int(seconds_needed)
            )
        )
